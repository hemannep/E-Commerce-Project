document.addEventListener("DOMContentLoaded", function() {
    const form = document.querySelector('.contact-form');
    form.addEventListener('submit', function(event) {
        event.preventDefault();

        // Validate each field
        let isValid = true;
        const fields = form.querySelectorAll('input[required], textarea[required]');
        fields.forEach(field => {
            if (!field.value.trim()) {
                isValid = false;
                field.style.borderColor = 'red'; // Highlight empty fields
            } else {
                field.style.borderColor = ''; // Reset field color
            }
        });

        if (isValid) {
            form.submit(); // Proceed with the form submission
            alert('Form submitted successfully');
        } else {
            alert('Please fill up all the places.');
        }
    });
});
