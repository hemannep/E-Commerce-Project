package com.gadegethub.controllers;


import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.gadgethub.database.DbConnection;
import com.gadgethub.items.User;

/**
 * Servlet implementation class UserLoginServlet
 */
@WebServlet("/login")
public class userlogin extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public userlogin() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Servlet#init(ServletConfig)
	 */
	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.getRequestDispatcher("/Customer/account.jsp").forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String email = request.getParameter("email");
		String password = request.getParameter("password");
		
		try {
			
			DbConnection dbCon = new DbConnection();
			
			Connection connection = dbCon.getConnection();
			
			String query = "SELECT * FROM users where email=? AND password=?;";
			
			PreparedStatement stmt = connection.prepareStatement(query);
			
			stmt.setString(1, email);
			stmt.setString(2, password);
			
			ResultSet rs = stmt.executeQuery();
			
			if(!rs.next()) {
				request.setAttribute("msg", "Invalid Credentials");
				response.sendRedirect("/Java/login");
				return;
			}
			
			
			User user = new User(rs.getInt("id"), rs.getString("email"), "", rs.getString("name"), rs.getString("address"), rs.getString("phone"), rs.getString("image"), rs.getInt("role"));
			
			HttpSession session = request.getSession();
			session.setAttribute("user", user);
			session.setAttribute("role", "user");
			
			stmt.close();
			connection.close();
			
			response.sendRedirect("/Java/products");
			
		}catch(SQLException ex) {
			ex.printStackTrace();
		}
	}

}
