package com.gadgethub.admin;


import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;
import java.util.UUID;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.tomcat.util.http.fileupload.FileItem;
import org.apache.tomcat.util.http.fileupload.FileUploadException;
import org.apache.tomcat.util.http.fileupload.disk.DiskFileItemFactory;
import org.apache.tomcat.util.http.fileupload.servlet.ServletFileUpload;
import org.apache.tomcat.util.http.fileupload.servlet.ServletRequestContext;

import com.gadgethub.database.DbConnection;
import com.gadgethub.items.Product;

/**
 * Servlet implementation class AddProductServlet
 */
@WebServlet("/product/add")
public class addproduct extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public addproduct() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Servlet#init(ServletConfig)
	 */
	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			addProduct(request, response);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
	protected void addProduct(HttpServletRequest request, HttpServletResponse response) throws Exception {
		String name = "";
		Double price = 0.0;
		int stock = 0;
		int categoryId = 1;
		String imageUrl = "";
		
		// Create a factory for disk-based file items
		DiskFileItemFactory factory = new DiskFileItemFactory();

		// Create a new file upload handler
		ServletFileUpload upload = new ServletFileUpload(factory);

		// Parse the request
		try {
			List<FileItem> items 
	          = upload.parseRequest(new ServletRequestContext(request));
		    
		    // Process the request items
		    for (FileItem item : items) {
		        if (item.isFormField()) {
		        	 // This is a regular form field
		            String fieldName = item.getFieldName();
		            String fieldValue = item.getString();
		            // Set the corresponding form field variable
		            if (fieldName.equals("name")) {
		                name = fieldValue;
		            } else if (fieldName.equals("price")) {
		                price = Double.parseDouble(fieldValue);
		            } else if (fieldName.equals("stock")) {
		                stock = Integer.parseInt(fieldValue);
		            } else if (fieldName.equals("categoryId")) {
		                categoryId = Integer.parseInt(fieldValue);
		            }
		        } else {
		            String fileName = item.getName();
		            
		            String uploadsPath = "C:\\Users\\heman\\Documents\\uploads";
		            
		            File uploadsDir = new File(uploadsPath);
		            
		            if (!uploadsDir.exists()) {
		                uploadsDir.mkdir();
		            }
		            // Generate a unique file name for the uploaded file
		            String uniqueFileName = UUID.randomUUID().toString() + "_" + fileName;
		            
		            // Create a new File object to save the file to disk
		            File file = new File(uploadsDir, uniqueFileName);

		            // Write the file to disk
		            item.write(file);

		            // Get the full file URL
		            String fileUrl = request.getContextPath() + "/uploads/" + uniqueFileName;
		            
		            imageUrl = fileUrl;
		        }
		    }
		} catch (FileUploadException e) {
			e.printStackTrace();
		}

		
		
		
		Product product = new Product(
				name, "sdaf", imageUrl, price, stock, categoryId, 4.5
				);
		
		try {
			DbConnection dbCon = new DbConnection();
			
			Connection connection = dbCon.getConnection();
			
			String query = "INSERT INTO products(name, description, image, price, quantity, category_id, rating) VALUES (?,?,?,?,?,?,?);";
			
			PreparedStatement stmt = connection.prepareStatement(query);
			
			stmt.setString(1, product.getName());
			stmt.setString(2, product.getDescription());
			stmt.setString(3, product.getImage());
			stmt.setDouble(4, product.getPrice());
			stmt.setInt(5, product.getQuantity());
			stmt.setInt(6, product.getCategoryId());
			stmt.setDouble(7, product.getRating());
			
			stmt.executeUpdate();
			
			
			stmt.close();
			connection.close();
			
			response.sendRedirect("/Java/admin");
		}catch(SQLException ex) {
			ex.printStackTrace();
		}
	}

}
