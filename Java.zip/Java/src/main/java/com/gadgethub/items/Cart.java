package com.gadgethub.items;



import com.gadgethub.items.Product;

public class Cart{
	private int orderId;
	private double price;
	private Product product;
	private int quantity;
	private double totalPrice;

	public Cart(int orderId, double price, Product product, int quantity, double totalPrice) {
		super();
		this.orderId = orderId;
		this.price = price;
		this.product = product;
		this.quantity = quantity;
		this.totalPrice = totalPrice;
	}

	public int getOrderId() {
		return orderId;
	}

	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public double getTotalPrice() {
		return totalPrice;
	}

	public void setTotalPrice(double totalPrice) {
		this.totalPrice = totalPrice;
	}

}
