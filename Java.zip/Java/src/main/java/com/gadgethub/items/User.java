package com.gadgethub.items;

import java.io.Serializable;

public class User implements Serializable {

    private static final long serialVersionUID = 1L;

    private int id;
    private String email;
    private String password;
    private String name;
    private String address;
    private String phone;
    private String image;
    private int role;
    
    // Constructor
    public User(int id, String email, String password, String name, String address, String phone, String image, int role) {
        this.id = id;
        this.email = email;
        this.password = password;
        this.name = name;
        this.address = address;
        this.phone = phone;
        this.image = image;
        this.role = role;
    }
    
    public User(String email, String password, String name, String address, String phone, String image, int role) {
        this.email = email;
        this.password = password;
        this.name = name;
        this.address = address;
        this.phone = phone;
        this.image = image;
        this.role = role;
    }
    
    // Getters
    public int getId() {
        return id;
    }
    
    public String getEmail() {
        return email;
    }
    
    public String getPassword() {
        return password;
    }
    
    public String getName() {
        return name;
    }
    
    public String getAddress() {
        return address;
    }
    
    public String getPhone() {
        return phone;
    }
    
    public String getImage() {
        return image;
    }
    
    public int getRole() {
        return role;
    }
    
    // Setters
    public void setId(int id) {
        this.id = id;
    }
    
    public void setEmail(String email) {
        this.email = email;
    }
    
    public void setPassword(String password) {
        this.password = password;
    }
    
    public void setName(String name) {
        this.name = name;
    }
    
    public void setAddress(String address) {
        this.address = address;
    }
    
    public void setPhone(String phone) {
        this.phone = phone;
    }
    
    public void setImage(String image) {
        this.image = image;
    }
    
    public void setRole(int role) {
        this.role = role;
    }
}
