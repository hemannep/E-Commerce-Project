package com.gadgethub.product;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.gadgethub.database.DbConnection;
import com.gadgethub.items.Product;

/**
 * Servlet implementation class ViewProductServlet
 */
@WebServlet("/products")
public class viewproducts extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public viewproducts() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Servlet#init(ServletConfig)
	 */
	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		List<Product> products = new ArrayList<Product>();
		
		try {
			DbConnection dbCon = new DbConnection();
			
			Connection connection = dbCon.getConnection();
			
			String query = "SELECT * FROM products";
			
			PreparedStatement stmt = connection.prepareStatement(query);
			
			ResultSet rs = stmt.executeQuery();
			
			while(rs.next()) {
				int id = rs.getInt("id");
				String name = rs.getString("name");
				String description = rs.getString("description");
				String image = rs.getString("image");
				Double price = rs.getDouble("price");
				int quantity = rs.getInt("quantity");
				int catId = rs.getInt("category_id");
				Double rating = rs.getDouble("rating");
				
				Product product = new Product(id, name, description, image, price, quantity, catId, rating);
				products.add(product);
			}
			
			stmt.close();
			connection.close();
			
			request.setAttribute("products", products);
			
		}catch(SQLException ex) {
			ex.printStackTrace();
		}
		request.getRequestDispatcher("/Customer/products.jsp").forward(request, response);
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
