package com.ecommerce.controllers;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.ecommerce.controllers.config.DbConnection;
import com.ecommerce.models.CartItemDetail;
import com.ecommerce.models.Product;
import com.ecommerce.models.User;

/**
 * Servlet implementation class ViewCartServlet
 */
@WebServlet("/cart")
public class ViewCartServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ViewCartServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Servlet#init(ServletConfig)
	 */
	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession();
		
		User user = (User) session.getAttribute("user");
		
		List<CartItemDetail> cartItems = new ArrayList<>();
		
		
		try {
			DbConnection dbCon = new DbConnection();
			
			Connection connection = dbCon.getConnection();
			
			String query = "select orders.id as order_id, order_items.price as ord_price, order_items.quantity as quan, products.* from orders "
					+ " INNER JOIN order_items ON orders.id = order_items.order_id "
					+ " INNER JOIN products on order_items.product_id=products.id "
					+ " where orders.order_status=0 AND orders.user_id=?;";
			
			
			PreparedStatement stmt = connection.prepareStatement(query);
			
			stmt.setInt(1, user.getId());
			
			ResultSet rs = stmt.executeQuery();
			
			while(rs.next()) {
				int orderId = rs.getInt("order_id");
				double orderPrice = rs.getDouble("ord_price");
				int quantity = rs.getInt("quan");
				int prodId = rs.getInt("id");
				String name = rs.getString("name");
				String description = rs.getString("description");
				String image = rs.getString("image");
				double price = rs.getDouble("price");
				int prodQuantity = rs.getInt("quantity");
				int categoryId = rs.getInt("category_id");
				int rating = rs.getInt("rating");
				
				Product prod = new Product(prodId,name, description,image,price,prodQuantity, categoryId, rating
						);
				
				double totalPrice = orderPrice * quantity;
				
				
				CartItemDetail cartItem = new CartItemDetail(orderId, orderPrice, prod, quantity, totalPrice);
				
				cartItems.add(cartItem);
			}
			
			double totalCartCost = 0.0;
			
			for(CartItemDetail cid : cartItems) {
				
				totalCartCost+=cid.getTotalPrice();
			}
			
			request.setAttribute("cartItems", cartItems);
			request.setAttribute("totalCost", totalCartCost);
			
			
			stmt.close();
			connection.close();
			
			
		}catch(SQLException ex) {
			ex.printStackTrace();
		}
		
		request.getRequestDispatcher("/Customer/cart.jsp").forward(request, response);
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
