package com.ecommerce.controllers;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.ecommerce.controllers.config.DbConnection;
import com.ecommerce.models.User;

/**
 * Servlet implementation class UserPasswordUpdate
 */
@WebServlet("/password-update")
public class UserPasswordUpdate extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UserPasswordUpdate() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Servlet#init(ServletConfig)
	 */
	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession();
		String password = request.getParameter("password");
		String newPassword = request.getParameter("newPassword");
		
		User user = (User) session.getAttribute("user");
		
		try {
			
//			String encryptedPassword = enc.encryptMessage(password.getBytes(), encKeyString.getBytes());
//			System.out.println(encryptedPassword);
			
			DbConnection dbCon = new DbConnection();
			
			Connection connection = dbCon.getConnection();
			
			String query = "SELECT * FROM users where email=? AND password=?;";
			
			PreparedStatement stmt = connection.prepareStatement(query);
			
			stmt.setString(1, user.getEmail());
			stmt.setString(2, password);
			
			ResultSet rs = stmt.executeQuery();
			
			if(!rs.next()) {
				request.setAttribute("msg", "Invalid Credentials");
				response.sendRedirect("/Java/profile/update");
				return;
			}
			
			
			stmt.close();
			
			String updatePwQuery = "UPDATE users SET password=? where id=?;";
			PreparedStatement stm = connection.prepareStatement(updatePwQuery);
			
			stm.setString(1, newPassword);
			stm.setInt(2, user.getId());
			
			boolean isUpdated = stm.executeUpdate()>0;
			
			stm.close();
			connection.close();
			
			if(isUpdated) {
				session.invalidate();
				response.sendRedirect("/Java/login");
			}else {
				response.sendRedirect("/Java/profile/update");
			}
			
		}catch(SQLException ex) {
			ex.printStackTrace();
		}
	}

}
