package com.ecommerce.controllers.admin;

import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.tomcat.util.http.fileupload.FileItem;
import org.apache.tomcat.util.http.fileupload.FileUploadException;
import org.apache.tomcat.util.http.fileupload.disk.DiskFileItemFactory;
import org.apache.tomcat.util.http.fileupload.servlet.ServletFileUpload;
import org.apache.tomcat.util.http.fileupload.servlet.ServletRequestContext;

import com.ecommerce.controllers.config.DbConnection;
import com.ecommerce.models.Product;

/**
 * Servlet implementation class EditProductServlet
 */
@WebServlet("/product/edit/*")
public class EditProductServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EditProductServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Servlet#init(ServletConfig)
	 */
	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int productId = Integer.parseInt(request.getPathInfo().substring(1));
		
		Product prod = null;
		
		try {
			DbConnection dbCon = new DbConnection();
			
			Connection connection = dbCon.getConnection();
			
			String query = "SELECT * FROM products where id=?;";
			
			PreparedStatement stmt = connection.prepareStatement(query);
			stmt.setInt(1, productId);
			
			ResultSet rs = stmt.executeQuery();
			
			while(rs.next()) {
				int id = rs.getInt("id");
				String name = rs.getString("name");
				String description = rs.getString("description");
				String image = rs.getString("image");
				Double price = rs.getDouble("price");
				int quantity = rs.getInt("quantity");
				int catId = rs.getInt("category_id");
				Double rating = rs.getDouble("rating");
				
				Product product = new Product(id, name, description, image, price, quantity, catId, rating);
				prod=product;
			}
			
			stmt.close();
			connection.close();
			
			request.setAttribute("product", prod);
			
		}catch(SQLException ex) {
			ex.printStackTrace();
		}
		
		request.getRequestDispatcher("/Admin/edit-product.jsp").forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int productId = Integer.parseInt(request.getPathInfo().substring(1));
		
		String name = "";
		Double price = 0.0;
		int stock = 0;
		String imageUrl = "";
		
		// Create a factory for disk-based file items
		DiskFileItemFactory factory = new DiskFileItemFactory();

		// Create a new file upload handler
		ServletFileUpload upload = new ServletFileUpload(factory);

		// Parse the request
		try {
			List<FileItem> items 
	          = upload.parseRequest(new ServletRequestContext(request));
		    
		    // Process the request items
		    for (FileItem item : items) {
		        if (item.isFormField()) {
		        	 // This is a regular form field
		            String fieldName = item.getFieldName();
		            String fieldValue = item.getString();
		            // Set the corresponding form field variable
		            if (fieldName.equals("name")) {
		                name = fieldValue;
		            } else if (fieldName.equals("price")) {
		                price = Double.parseDouble(fieldValue);
		            } else if (fieldName.equals("stock")) {
		                stock = Integer.parseInt(fieldValue);
		            }
		        } else {
		        	// This is an uploaded file
		            String fieldName = item.getFieldName();
		            String fileName = item.getName();
		            String contentType = item.getContentType();
		            long sizeInBytes = item.getSize();
		            
		            String uploadsPath = "C:\\Users\\heman\\Documents\\uploads";
		            
		            File uploadsDir = new File(uploadsPath);
		            
		            if (!uploadsDir.exists()) {
		                uploadsDir.mkdir();
		            }
		            
		            
		           
		            // Generate a unique file name for the uploaded file
		            String uniqueFileName = UUID.randomUUID().toString() + "_" + fileName;
		            
		            // Create a new File object to save the file to disk
		            File file = new File(uploadsDir, uniqueFileName);

		            // Write the file to disk
		            item.write(file);

		            // Get the full file URL
		            String fileUrl = request.getContextPath() + "/uploads/" + uniqueFileName;
		            
		            imageUrl = fileUrl;
		        }
		    }
		} catch (FileUploadException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}

		
		Product product = new Product(
				name, "sdaf", imageUrl, price, stock, 0, 4.5
				);
		
		try {
			DbConnection dbCon = new DbConnection();
			
			Connection connection = dbCon.getConnection();
			
			String query = "UPDATE products SET name=?,image=?,price=?,quantity=? WHERE id=?";
			
			PreparedStatement stmt = connection.prepareStatement(query);
			
			stmt.setString(1, product.getName());
			stmt.setString(2, product.getImage());
			stmt.setDouble(3, product.getPrice());
			stmt.setInt(4, product.getQuantity());
			stmt.setInt(5, productId);
			
			boolean isUpdated = stmt.executeUpdate()>0;
			
			
			stmt.close();
			connection.close();
			
			if(isUpdated) {
				response.sendRedirect("/Java/admin");
			}
		}catch(SQLException ex) {
			ex.printStackTrace();
		}
	}

}
