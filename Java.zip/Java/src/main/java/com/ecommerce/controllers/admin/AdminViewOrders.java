package com.ecommerce.controllers.admin;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ecommerce.controllers.config.DbConnection;
import com.ecommerce.models.AdminOrderDetail;
import com.ecommerce.models.Product;

/**
 * Servlet implementation class AdminViewOrders
 */
@WebServlet("/admin/orders")
public class AdminViewOrders extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AdminViewOrders() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Servlet#init(ServletConfig)
	 */
	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		List<AdminOrderDetail> products = new ArrayList<AdminOrderDetail>();
		
		try {
			DbConnection dbCon = new DbConnection();
			
			Connection connection = dbCon.getConnection();
			
			String query = "SELECT orders.id, users.name, orders.order_date, SUM(order_items.quantity*order_items.price) AS total_price FROM orders INNER JOIN users ON orders.user_id = users.id  INNER JOIN order_items ON orders.id = order_items.order_id GROUP BY orders.id;";
			
			PreparedStatement stmt = connection.prepareStatement(query);
			
			ResultSet rs = stmt.executeQuery();
			
			while(rs.next()) {
				products.add(new AdminOrderDetail(
						rs.getInt("id"),
						rs.getString("name"),
						rs.getDouble("total_price"),
						rs.getString("order_date")
						));
			}
			
			stmt.close();
			connection.close();
			
			request.setAttribute("orders", products);
			
		}catch(SQLException ex) {
			ex.printStackTrace();
		}
		request.getRequestDispatcher("/Admin/view-order.jsp").forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
