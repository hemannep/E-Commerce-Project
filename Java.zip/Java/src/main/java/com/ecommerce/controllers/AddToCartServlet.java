package com.ecommerce.controllers;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Date;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.ecommerce.controllers.config.DbConnection;
import com.ecommerce.models.Product;
import com.ecommerce.models.User;

/**
 * Servlet implementation class AddToCartServlet
 */
@WebServlet("/cart/add")
public class AddToCartServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddToCartServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Servlet#init(ServletConfig)
	 */
	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		addItemToCart(request,response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		addItemToCart(request,response);
	}
	
	private boolean isOrderPending(HttpServletRequest request, HttpServletResponse response) {
		HttpSession session = request.getSession();
		
		User user = (User) session.getAttribute("user");
		
		
		try {
			DbConnection dbCon = new DbConnection();
			
			Connection connection = dbCon.getConnection();
			
			String query = "SELECT * FROM orders WHERE user_id=? AND order_status=0;";
			
			PreparedStatement stmt = connection.prepareStatement(query);
			
			stmt.setInt(1, user.getId());
			
			ResultSet rs = stmt.executeQuery();
			
			if(rs.next()) {
				return true;
			}
			
			stmt.close();
			connection.close();
			
			
		}catch(SQLException ex) {
			ex.printStackTrace();
		}
		
		return false;
	}
	
	private int getOrderId(HttpServletRequest request, HttpServletResponse response) {
		if(isOrderPending(request,response)) {
			HttpSession session = request.getSession();
			
			User user = (User) session.getAttribute("user");
			
			
			try {
				DbConnection dbCon = new DbConnection();
				
				Connection connection = dbCon.getConnection();
				
				String query = "SELECT * FROM orders WHERE user_id=? AND order_status=0;";
				
				PreparedStatement stmt = connection.prepareStatement(query);
				
				stmt.setInt(1, user.getId());
				
				ResultSet rs = stmt.executeQuery();
				
				if(rs.next()) {
					return rs.getInt("id");
				}
				
				stmt.close();
				connection.close();
				
				
			}catch(SQLException ex) {
				ex.printStackTrace();
			}
			
			return -1;
		}else {
			return -1;
		}
	}
	
	private boolean createOrder(HttpServletRequest request, HttpServletResponse response) {
		HttpSession session = request.getSession();
		
		User user = (User) session.getAttribute("user");
		
		
        LocalDate currentDate = LocalDate.now();
        
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        String formattedDate = currentDate.format(formatter);

		
		
		try {
			DbConnection dbCon = new DbConnection();
			
			Connection connection = dbCon.getConnection();
			
			String query = "INSERT INTO orders(user_id, total_price, order_date, order_status) VALUES (?,?,?,?)";
			
			PreparedStatement stmt = connection.prepareStatement(query);
			
			stmt.setInt(1, user.getId());
			stmt.setDouble(2, 0.0);
			stmt.setString(3, formattedDate);
			stmt.setInt(4, 0);
			
			
			boolean isCreated =  stmt.executeUpdate()>0;
			
			
			stmt.close();
			connection.close();
			
			return isCreated;
			
			
		}catch(SQLException ex) {
			ex.printStackTrace();
		}
		
		return false;
	}
	
	
	
	private void addItemToCart(HttpServletRequest request, HttpServletResponse response) throws IOException {
		int prodId = Integer.parseInt(request.getParameter("prodId"));
		int quantity = Integer.parseInt(request.getParameter("quantity"));
		double price = Double.parseDouble(request.getParameter("price"));
		
		boolean isOrderPending = isOrderPending(request,response);
		
		if(!isOrderPending) {
			createOrder(request,response);
		}
		
		int orderId = getOrderId(request,response);
		
		try {
			DbConnection dbCon = new DbConnection();
			
			Connection connection = dbCon.getConnection();
			
			String query = "INSERT INTO order_items(order_id, product_id, quantity, price) VALUES (?,?,?,?)";
			
			PreparedStatement stmt = connection.prepareStatement(query);
			
			stmt.setInt(1, orderId);
			stmt.setInt(2, prodId);
			stmt.setInt(3, quantity);
			stmt.setDouble(4, price);
			
			
			boolean isCreated =  stmt.executeUpdate()>0;
			
			
			stmt.close();
			connection.close();
			
			if(isCreated) {
				response.sendRedirect("/Java/cart");
			}
			
		}catch(SQLException ex) {
			ex.printStackTrace();
		}
	}
	
	

}
