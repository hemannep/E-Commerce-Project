package com.ecommerce.controllers.config;

public class DbConfig {
    protected final String url = "jdbc:mysql://localhost:3306/coursework";
    protected final String username = "root";
    protected final String password = "";
}
